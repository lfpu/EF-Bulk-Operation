# MOLD OBJ > 2024-09-11 12:38am
https://universe.roboflow.com/longfeipu-rztib/mold-obj

Provided by a Roboflow user
License: CC BY 4.0

